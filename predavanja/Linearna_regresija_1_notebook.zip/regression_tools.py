import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import numpy.linalg as la
from sklearn.linear_model import LinearRegression


def simple_linear_regression(df,x,y):
    x_train = np.array(df[x]).reshape(-1, 1)
    y_train = np.array(df[y]).reshape(-1, 1)
    
    model = LinearRegression()
    model.fit(x_train, y_train)
    
    slope = model.coef_[0][0]
    intercept = model.intercept_[0]
    
    g = sb.lmplot(x=x, y=y, data=df, height=10, aspect=1.5, ci=None,scatter_kws={'clip_on': False})
    
    plt.legend(title='Jednostruka regresija', loc='upper left', labels=['y={0:.5f}x+{1:.5f}'.format(slope, intercept)])
    
    plt.show(g)


def plot_points(x,y,xlabel,ylabel):
    plt.figure(figsize=(15, 10))
    plt.plot(x,y,'ob', markersize = 5, markerfacecolor = 'b')
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    

def lsquares(x,y,stepen):
    n=len(x)
    A=np.zeros([n,stepen+1])

    for i in range(n):
        for j in range(stepen+1):
            A[i,j]=x[i]**j

    p=la.solve(np.matmul(A.T, A), np.matmul(A.T, y.T))
    p=np.flip(p)
    
    return p


def calcluate_SSE(x,y):
    tmp_xx=np.linspace(-10,15,100)
    xx, yy = np.meshgrid(tmp_xx, tmp_xx, sparse=False, indexing='ij')
    
    SSE = np.zeros([len(xx),len(xx)])
    SSE_as_list = []
    
    for i in range(len(xx)):
        for j in range(len(xx)):
            pred = xx[i,j]*x + yy[i,j]
            tmp_list = [xx[i,j],yy[i,j],np.sum((pred-y)**2)]
            SSE_as_list.append(tmp_list)
    
    SSE_as_matrix = np.matrix(SSE_as_list)
    
    return pd.DataFrame(data=SSE_as_matrix,columns=['k','n','SSE'])